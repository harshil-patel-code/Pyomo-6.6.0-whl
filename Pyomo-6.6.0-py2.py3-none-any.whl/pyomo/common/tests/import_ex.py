def a():
    pass


b = 2
