# Define a 'load()' function, which simply imports
# sub-packages that define plugin classes.


def load():
    import pyomo.contrib.example.plugins.ex_plugin
