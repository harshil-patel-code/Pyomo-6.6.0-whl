# Tests for pyomo.contrib.example
