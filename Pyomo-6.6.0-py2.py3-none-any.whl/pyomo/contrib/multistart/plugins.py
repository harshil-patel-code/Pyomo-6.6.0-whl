def load():
    import pyomo.contrib.multistart.multi
