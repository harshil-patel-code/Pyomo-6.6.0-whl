class WriterConfig(object):
    def __init__(self):
        self.symbolic_solver_labels = False
