#include "common.hpp"

double inf;
